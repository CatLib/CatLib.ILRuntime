
# CatLib For Unity

这是CatLib For Unity的引导框架，您不应该手动修改这个文件夹下的任何内容，这会导致未来升级框架变得困难。

## 技术支持

* 通过[框架帮助文档](https://catlib.io)自行查找解决方案（推荐）
* 通过[Issues](https://github.com/CatLib/CatLib/issues)直接发起问题（推荐）
* QQ群: 150371044 (验证: CatLib Support)
* email: support@catlib.io
* slack: [catlib.slack](https://catlib.slack.com/messages/internals/)
